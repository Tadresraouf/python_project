import requests
import bs4

url = "https://www.abdomarket.com/?s=%D8%B3%D8%A7%D8%B9%D8%A9+%D8%B1%D8%AC%D8%A7%D9%84%D9%8A&post_type=product&dgwt_wcas=1"

result = requests.get(url)

doc = bs4.BeautifulSoup(result.content, "html.parser")

product = doc.find_all('div', {'class': 'product-wrapper'})

for Item in product:
	print(Item.find('h3',{'class':'wd-entities-title'}).text)
	print(Item.find('span', {'class': 'price'}).text)
	print()